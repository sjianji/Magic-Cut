
var exports=exports||{};

function checkDirty(t)
{
	if(t.tweenDirty)
	{
		for(var index=0;index<t.actions.length;index++)
		{
			var action=t.actions[index];
			var target=null;
			var from={};
			var to={};
			
			if(!!action.startPosition)
			{
				target=t.transform;
				from["targetPosition"]=action.startPosition;
			}
			
			if(!!action.endPosition)
			{
				target=t.transform;
				to["targetPosition"]=action.endPosition;
			}
			
			if(action.startAlpha!=null)
			{
				target=t.filter;
				from["alpha"]=action.startAlpha;
			}
			
			if(action.endAlpha!=null)
			{
				target=t.filter;to["alpha"]=action.endAlpha;
			}
			
			action.tween=VECore.createTween(target,from,to,t.duration*(action.end-action.start),action.actionCB);
		}
		
		t.tweenDirty=false;
	}
}

function Transform()
{
	this.tweenDirty=true;
	this.filter=null;
	this.transform=null;
	this.duration=0;
}

Transform.prototype.onStart=function(context)
{
	this.filter=context.getFilter("text");
	this.transform=this.filter.getComponent("Transform");
	var tw=context.getTextureRect().getSize().x;
	var sw=context.getScreenSize().x;
	this.actions=[
		{startAlpha:1,endAlpha:1,actionCB:VECore.Tween.Easing.Quadratic.Out,start:0.0,end:1},
		{startPosition:new VECore.Vec3(tw/sw/2.0,0,0.0),endPosition:new VECore.Vec3(-tw/sw/2.0,0,0.0),actionCB:VECore.Tween.Easing.Quadratic.Out,start:0.0,end:1}
		];
	this.tweenDirty=true;
	checkDirty(this);
}

Transform.prototype.onSeek=function(time)
{
	checkDirty(this);
	for(var index=0;index<this.actions.length;index++)
	{
		var action=this.actions[index];
		var progress=time/this.duration;
		if(progress>=action.start&&progress<=action.end)
		{
			action.tween.seek(time-action.start*this.duration);
		}
	}
}

Transform.prototype.setDuration=function(duration)
{
	this.duration=duration;
	this.tweenDirty=true;
}

Transform.prototype.onClear=function()
{
	for(var index=0;index<this.actions.length;index++)
	{
		let action=this.actions[index];
		action.tween.seek(0);
		action.tween.clear();
	}
	this.tweenDirty=true;
}
exports.Transform=Transform;export{exports}
