
var exports=exports||{};
function MergeAnim()
{
	this.filter=null;
	this.duration=0;
    this.appearDur = 0.0;
    this.maxYOffset = -0.4;
    this.offset = 0.0;
}

function setText0(t,time)
{
    var yOffset = 0;
    var alpha = 1;
    if (time <= t.appearDur)
	{
        yOffset = 0.0;
        alpha = time / t.appearDur;
	}	
    else
	{
        var pct = (time - t.appearDur) / (t.duration - t.appearDur);
        yOffset = pct * t.maxYOffset;
        alpha = (1.0 - pct);
    }
	
	t.filter.u_yOffset = yOffset;
	t.filter.u_alpha = alpha;
}

function setText1(t,time)
{
    var yOffset = 0;
    var alpha = 1;
    if (time <= t.appearDur)
	{
        yOffset = 0.0;
        alpha = time / t.appearDur;
	}	
    else
	{
        var pct = (time - t.appearDur) / (t.duration - t.appearDur);
        yOffset = pct * t.maxYOffset;
        alpha = (1.0 - pct);
    }
	
	t.filter.u_yOffset1 = yOffset;
	t.filter.u_alpha1 = alpha;
}

function setText2(t,time)
{
    var yOffset = 0;
    var alpha = 1;
    if (time <= t.appearDur)
	{
        yOffset = 0.0;
        alpha = time / t.appearDur;
	}	
    else
	{
        var pct = (time - t.appearDur) / (t.duration - t.appearDur);
        yOffset = pct * t.maxYOffset;
        alpha = (1.0 - pct);
    }
	
	t.filter.u_yOffset2 = yOffset;
	t.filter.u_alpha2 = alpha;
}


MergeAnim.prototype.onStart=function(context)
{
	this.filter=context.getFilter("text");
	this.filter.mergeRender = true;
}

MergeAnim.prototype.onSeek=function(time)
{
	var duration = this.duration;
	
	this.filter.mergeRender = true;
	
	setText0(this,time % duration);
	setText1(this,(time + this.offset) % duration);
	setText2(this,(time + this.offset * 2.0) % duration);
}

MergeAnim.prototype.setDuration=function(duration)
{
	this.duration=duration;
    this.offset = this.duration / 3;
    this.appearDur = this.offset;
}

MergeAnim.prototype.onClear=function()
{
}
exports.MergeAnim=MergeAnim;export{exports}