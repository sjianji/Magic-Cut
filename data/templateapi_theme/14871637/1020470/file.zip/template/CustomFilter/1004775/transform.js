var exports = exports || {};


function getBezierValue(controls, t) {
    let xc1 = controls[0];
    let yc1 = controls[1];
    let xc2 = controls[2];
    let yc2 = controls[3];
    return [
        3 * xc1 * (1 - t) * (1 - t) * t + 3 * xc2 * (1 - t) * t * t + t * t * t,
        3 * yc1 * (1 - t) * (1 - t) * t + 3 * yc2 * (1 - t) * t * t + t * t * t
    ];
}

function getBezierTfromX(controls, x) {
    let ts = 0.0;
    let te = 1.0;
    do {
        let tm = (ts + te) / 2.0;
        let value = getBezierValue(controls, tm)
        if (value[0] > x)
            te = tm;
        else
            ts = tm;
    }
    while ((te - ts) >= 0.0001);
    return (te + ts) / 2.0;
}

function tweenCallback2(t, b, c, d) {
    t = t / d;
    let controls = [0, 0, 1, 1];
    let tvalue = getBezierTfromX(controls, t);
    let value = getBezierValue(controls, tvalue);
    return b + c * value[1];
}
function tweenCallback1(t, b, c, d) {
    t = t / d;
    if (t != 0.0 && t != 1.0) {
        t = Math.exp(-7.0 * t) * 1.0 * Math.sin((t - 0.075) * (1.5 * Math.PI) / 0.3) + 1.0;
    }
    return VECore.Tween.Easing.Linear(t, b, c);
}

function tweenBlurCallback(t, b, c, d) {
    t = t / d;
    return 1.0 - (0.4 * (Math.max(1 - t, 0.4) - 0.4));
}

function Transform() {
    this.tweenDirty = true;
    this.filter = null;
    this.transform = null;
    this.duration = 0;
    this.actions =
        [
            {
                anchorPoint: new VECore.Vec2(0, 2), //旋转中心点
                startRotate: new VECore.Vec3(0.0, 0.0, -35.0),
                endRotate: new VECore.Vec3(0.0, 0.0, 0.0),
                actionCB: tweenCallback1,
                // 起始时间占比
                start: 0.0,
                // 结束时间占比
                end: 1
            },
            //运动模糊
            {
                // 模糊强度
                blurIntensity: 5,
                // 模糊类型，0不模糊，1方向，2缩放
                blurType: 1,
                // 模糊方向
                blurDirection: new VECore.Vec2(1, 0),
                // 插值曲线
                actionCB: tweenCallback1,
                // 起始时间占比
                start: 0.0,
                // 结束时间占比
                end: 1.0
            },
        ];
}

Transform.prototype.onStart = function (context) {
    this.filter = context.getFilter("default");
    this.filter.enableMacro("BLUR_TYPE", 0);
    this.transform = this.filter.getComponent("Transform");
    this.tweenDirty = true;
    checkDirty(this);
}

function checkDirty(t) {
    if (t.tweenDirty) {
        for (var index = 0; index < t.actions.length; index++) {
            var action = t.actions[index];
            var target = null;
            var from = {};
            var to = {};


            if (!!action.startPosition) {
                target = t.transform;
                from["srcPosition"] = action.startPosition;
            }

            if (!!action.startScale) {
                target = t.transform;
                from["srcScale"] = action.startScale;
            }

            if (!!action.startRotate) {
                target = t.transform;
                from["srcRotate"] = action.startRotate;
                if (!!action.anchorPoint) {
                    target.srcAnchorPoint = action.anchorPoint;
                }
            }

            if (!!action.endPosition) {
                target = t.transform;
                to["srcPosition"] = action.endPosition;
            }

            if (!!action.endScale) {
                target = t.transform;
                to["srcScale"] = action.endScale;
            }

            if (!!action.endRotate) {
                target = t.transform;
                to["srcRotate"] = action.endRotate;
                if (!!action.anchorPoint) {
                    target.srcAnchorPoint = action.anchorPoint;
                }
            }

            if (action.blurType != null) {
                target = t.filter;
                t.filter.enableMacro("BLUR_TYPE", action.blurType);
                t.filter["blurDirection"] = action.blurDirection;
                from["blurStep"] = action.blurIntensity / (t.duration * (action.end - action.start));
                to["blurStep"] = 0.0;
            }

            if (action.startAlpha != null) {
                target = t.filter;
                from["alpha"] = action.startAlpha;
            }

            if (action.endAlpha != null) {
                target = t.filter;
                to["alpha"] = action.endAlpha;
            }

            action.tween = VECore.createTween(target, from, to, t.duration * (action.end - action.start), action.actionCB);
        }
        t.tweenDirty = false;
    }
}

Transform.prototype.onSeek = function (time) {
    checkDirty(this);
    for (var index = 0; index < this.actions.length; index++) {
        var action = this.actions[index];
        var progress = time / this.duration;

        if (progress >= action.start) {
            action.tween.seek(time - action.start * this.duration);
        }
    }
}
//持续时间
Transform.prototype.setDuration = function (duration) {
    this.duration = duration;
    this.tweenDirty = true;
}

Transform.prototype.onClear = function () {
    for (var index = 0; index < this.actions.length; index++) {
        let action = this.actions[index];
        action.tween.seek(0);
        action.tween.clear();
    }
    this.tweenDirty = true;
}

exports.Transform = Transform;
export { exports }